﻿using HTGMTMQ_QR.BackendServer.Data;
using HTGMTMQ_QR.BackendServer.Data.Entities;
using HTGMTMQ_QR.ViewModels.Systems.SanPham;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace HTGMTMQ_QR.BackendServer.Controllers
{
    [Route("api/order")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly ApplicationDbcontext _context;

        public OrderController(ApplicationDbcontext context)
        {
            _context = context;
        }

        [AllowAnonymous]
        [HttpPost("add-item")]
        public async Task<IActionResult> AddItem(AddItemVm model)
        {
            var hoadon = await _context.HoaDons.FindAsync(model.MaHD);
            if (hoadon == null)
                return NotFound("Không tìm thấy hóa đơn.");

            var sanpham = await _context.SanPhams.FindAsync(model.MaSP);
            if (sanpham == null)
                return NotFound("Không tìm thấy sản phẩm.");

            // kiểm tra món đã tồn tại chưa
            var item = await _context.ChiTietHoaDons
                .FirstOrDefaultAsync(x => x.MaHD == model.MaHD && x.MaSP == model.MaSP);

            if (item != null)
            {
                item.SoLuong += model.SoLuong;
            }
            else
            {
                item = new ChiTietHoaDon
                {
                    MaHD = model.MaHD,
                    MaSP = model.MaSP,
                    SoLuong = model.SoLuong,
                    DonGia = sanpham.DonGia,
                    TrangThaiMon = "Đang nấu"
                };

                _context.ChiTietHoaDons.Add(item);
            }

            await _context.SaveChangesAsync();

            // cập nhật tổng tiền
            hoadon.TongTien = await _context.ChiTietHoaDons
                .Where(x => x.MaHD == model.MaHD)
                .SumAsync(x => x.SoLuong * x.DonGia);

            await _context.SaveChangesAsync();

            return Ok(new { message = "Thêm món thành công." });
        }

        // GET: api/order/{mahd}
        [AllowAnonymous]
        [HttpGet("{mahd}")]
        public async Task<IActionResult> GetOrder(int mahd)
        {
            var items = await _context.ChiTietHoaDons
                .Where(x => x.MaHD == mahd)
                .Select(x => new
                {
                    x.MaCTHD,
                    x.MaSP,
                    x.SoLuong,
                    x.DonGia,
                    x.TrangThaiMon
                })
                .ToListAsync();

            return Ok(items);
        }



    }
}
